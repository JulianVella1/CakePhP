<?php
return [
    'firebase' => [
        'apiKey' => 'AIzaSyAyG8gDH_n78C0QvNgG22MOCPccvByfe2A',
        'authDomain' => 'purrfect-julian.firebaseapp.com',
        'projectId' => 'purrfect-julian',
        'storageBucket' => 'purrfect-julian.firebasestorage.app',
        'messagingSenderId' => '619893503024',
        'appId' => '1:619893503024:web:93e2cfc2ab1ea1cdcc29f5'
    ]
];
